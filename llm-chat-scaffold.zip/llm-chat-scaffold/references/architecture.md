# Architecture Reference

이 문서는 스캐폴드의 **비자명한 설계 결정**을 설명한다. 파일을 복사해 조립할 때, 그리고
이후 확장·디버깅할 때 참고한다.

## 전체 구조 & 데이터 흐름

```
사용자 입력
  → [Frontend] Composer → chatRunner.sendMessage
  → POST /api/sessions/{id}/chat  (SSE 스트림)
  → [Backend] chat 라우터 → LangGraph.astream (thread_id=session_id)
  → chat 노드: [SystemPrompt, ...history] → model.ainvoke
  → 토큰이 SSE `token` 프레임으로 스트리밍 → done
  → [Frontend] 버퍼에 모았다가 done 시 마크다운 렌더
```

3계층: **React(Vite) UI** ↔ **FastAPI API** ↔ **LangGraph(+LLM)**. 상태 영속화는 전부 SQLite.

## 메모리 모델 — 이 스캐폴드의 핵심

대화 기억은 **LangGraph 체크포인터**가 담당한다. 직접 messages 테이블을 만들지 않는다.

- `main.py` 의 lifespan 에서 `AsyncSqliteSaver.from_conn_string(db_path)` 로 체크포인터를 만들고
  `build_graph(model, checkpointer)` 에 넘긴다. compile 에 체크포인터가 붙으면 **모든 노드가
  자동으로 세션별 메모리**를 갖는다.
- 매 호출마다 `cfg = {"configurable": {"thread_id": session_id}}` 를 넘긴다. **thread_id 가
  곧 세션 식별자**다. 같은 thread_id 로 다시 부르면 체크포인터가 이전 `messages` 상태를 복원해
  자동으로 앞에 붙여준다 → 세션 내 대화가 이어진다.
- `GraphState.messages` 에는 `add_messages` reducer 가 붙어 있어 노드가 반환한 새 메시지가
  기존 히스토리에 **append** 된다(덮어쓰기 아님).
- 세션을 **삭제**하면 `sessions` 행 삭제 + `checkpointer.adelete_thread(session_id)` 로
  체크포인트까지 지운다(고아 상태 방지).

### `sessions` 테이블은 메타데이터 전용

`db/database.py` 의 `sessions` 테이블은 목록/제목/정렬용 메타데이터(id, title, created_at,
updated_at)만 저장한다. **실제 대화 메시지는 체크포인터의 별도 테이블**(checkpointer가 자동
생성)에 있다. 과거 메시지를 UI 로 로드할 때는 `messages_util.load_history` 가
`graph.aget_state(cfg)` 로 체크포인터 스냅샷을 읽어 직렬화한다 — sessions 테이블을 읽는 게 아니다.

> 이 분리가 핵심 설계다. "기본적인 DB 토대"를 확장할 때는 sessions 테이블에 컬럼/테이블을
> 추가하고(예: users, 태그), 대화 메시지 자체는 체크포인터에 맡긴다.

## LLM 백엔드 스위칭

`config.py` 의 `llm_backend` (`"ollama"` | `"internal"`) 한 값으로 전환한다. `.env` 또는
환경변수 `LLM_BACKEND` 로 주입.

- **ollama**: `llm._ollama_model` → `ChatOllama(model, base_url, client_kwargs)`. api_key 가
  있으면 Authorization 헤더로.
- **internal**: `llm._internal_model` → `ChatOpenAI(model, base_url, api_key)` (OpenAI 호환
  게이트웨이). base_url 은 `/v1` 포함 권장. 키가 필요 없으면 빈 값 → `"not-needed"` placeholder.

### 사내망 TLS / 프록시 (internal 전용)

사내 OpenAI 호환 API 는 사설 CA·프록시 뒤에 있는 경우가 많다. `net.py` 가 처리한다:

- `resolve_ssl_verify`: `INTERNAL_LLM_CA_BUNDLE`(.pem 경로) 있으면 그 CA 로 검증 유지(권장).
  없고 `INTERNAL_LLM_VERIFY_SSL=false` 면 검증 끔(비보안). 그 외 True.
  이 값은 httpx 클라이언트의 `verify` 인자로 들어가 `ChatOpenAI` 의 http_client 에 주입된다.
- `apply_proxy_bypass`: `BYPASS_PROXY=true` 면 프로세스의 HTTP(S)_PROXY 환경변수를 비운다.
  **HTTP 클라이언트가 만들어지기 전(lifespan 시작 시)** 호출해야 효과가 있다.

## LLM 연결 테스트

- 백엔드 `GET /api/health/llm` → `services/llm_health.check_llm` → 활성 백엔드로 디스패치.
  - ollama: `GET {base_url}/api/tags` → `{ok, models, error}`
  - internal: `GET {base_url}/models` → `{ok, models, error}`
  - 응답 형태는 백엔드와 무관하게 `{ok, models, error}` 로 통일(프론트 호환).
- 프론트 `LlmTestButton` 이 이 엔드포인트를 호출해 dot 색(초록/빨강/회색)과 title(모델 목록/에러)로
  표시한다.

## SSE 스트리밍 프로토콜

`api/sse.py` `format_sse(event, data)` → `event: <name>\ndata: <json>\n\n`.

이 스캐폴드가 쓰는 이벤트(3종):

| event   | data              | 의미                     |
|---------|-------------------|--------------------------|
| `token` | `{delta: string}` | assistant 텍스트 조각    |
| `done`  | `{session_id}`    | 정상 종료                |
| `error` | `{message}`       | 스트리밍 중 오류         |

- 백엔드: `graph.astream(inputs, cfg, stream_mode="messages")` → `(chunk, meta)` 튜플.
  `meta["langgraph_node"] == "chat"` 인 조각만 `token` 으로 흘린다(다른 노드 추가 시 누출 방지).
- 프론트: `api/sse.ts readSSE` 가 `\n\n` 경계로 프레임을 잘라 파싱하고 핸들러로 디스패치.

### 프론트는 왜 버퍼링 후 한 번에 렌더하나

`chatRunner.ts` 는 `token` 을 **버퍼에 모으기만** 하고, `done` 시점에
`setLastAssistantContent(buffer)` 로 한 번에 채운다. 마크다운(표/코드펜스/mermaid)은 조각
단위로 파싱하면 깨지므로, **완성된 응답을 통째로 렌더**해야 표·볼드·다이어그램이 올바로 그려진다.
그 사이 UI 는 `MessageList` 의 로딩 dot 을 보여준다(마지막 assistant 메시지가 빈 문자열 + streaming).

> 토큰 단위 실시간 표시를 원하면 `appendAssistantDelta(delta)`(store 에 이미 있음)를
> `onToken` 에서 호출하도록 바꾼다. 단, 렌더 중 마크다운이 깨질 수 있음을 감안한다.

## 마크다운 렌더링 (사용자 친화 출력)

- `CHAT_SYSTEM_PROMPT`(`prompts.py`)가 모델에게 **GitHub Flavored Markdown**으로, 표·불릿·
  `##`제목·`**굵게**`·mermaid flowchart 를 쓰도록 지시한다.
- `AssistantMessage.tsx` 가 `react-markdown` + `remark-gfm` 으로 렌더한다. 커스텀 렌더러:
  - `code`: `language-mermaid` → `MermaidDiagram` 다이어그램, 기타 펜스 → `<pre>`, 인라인 → `<code>`
  - `table/th/td`: 테두리·배경 스타일
  - `a`: 새 탭 링크
- `MermaidDiagram.tsx`: `mermaid.initialize({securityLevel:"strict"})` 로 안전하게 SVG 렌더,
  실패 시 원본 코드 폴백.

## API 계약 (엔드포인트)

| Method | Path                              | 설명                                    |
|--------|-----------------------------------|-----------------------------------------|
| GET    | `/`                               | `{status:"ok"}` 헬스                     |
| GET    | `/api/health/llm`                 | LLM 연결/모델 목록 `{ok,models,error}`   |
| POST   | `/api/sessions`                   | 세션 생성 → Session                      |
| GET    | `/api/sessions`                   | 세션 목록 (updated_at desc)              |
| PATCH  | `/api/sessions/{id}`              | 제목 변경 → Session                      |
| DELETE | `/api/sessions/{id}`              | 세션 + 체크포인트 삭제 (204)             |
| GET    | `/api/sessions/{id}/messages`     | 과거 대화 복원 `{messages:[{role,content}]}` |
| POST   | `/api/sessions/{id}/chat`         | 채팅 (SSE 스트림)                        |

첫 채팅 메시지면 제목을 첫 40자로 자동 유도(`_derive_title`), 아니면 `updated_at` 만 갱신해
목록 상단으로 올린다.

## 확장 지점

- **그래프 노드 추가**: `graph/builder.py` 에서 `sg.add_node(...)` + 조건부 엣지. 라우터 노드를
  두고 chat 과 도구 노드를 분기하는 식으로 확장(원본 프로젝트는 이 패턴으로 PPT 생성 노드를
  붙였다). 체크포인터는 compile 에 한 번만 붙이면 모든 노드에 적용된다.
- **DB 확장**: `db/database.py` `_SCHEMA` 에 테이블/컬럼 추가, `db/` 에 repo 모듈 추가.
- **SSE 이벤트 추가**: 백엔드 `stream_graph` 에서 새 `format_sse(event, ...)` 를 yield 하고,
  프론트 `sse.ts` `StreamHandlers` + `readSSE` 디스패치에 케이스를 추가.
- **인증 헤더**: 프론트 `api/headers.ts` `API_HEADERS` 에 추가(모든 fetch 가 스프레드).

## 기술 스택 요약

- Backend: FastAPI, LangGraph(+langgraph-checkpoint-sqlite), langchain-core/ollama/openai,
  aiosqlite, pydantic-settings, httpx. Python ≥3.11. 테스트: pytest(asyncio_mode=auto).
- Frontend: React 18, Vite 5, TypeScript, Zustand, react-markdown + remark-gfm, mermaid,
  Tailwind. 테스트: vitest + @testing-library/react (jsdom).
