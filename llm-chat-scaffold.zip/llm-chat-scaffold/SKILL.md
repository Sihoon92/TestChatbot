---
name: llm-chat-scaffold
description: "Build a full-stack LLM chat application from a bundled, working template: a FastAPI + LangGraph backend and a React + Vite + Tailwind frontend, with a switchable Ollama / 사내(internal OpenAI-compatible) LLM backend, per-session conversation memory persisted in SQLite via a LangGraph checkpointer, full session CRUD, an LLM connection-test button, and markdown (table/bold/mermaid) rendering. Use this skill when asked to create a chat app, LLM chatbot, Ollama or 사내 LLM web UI, a 채팅 앱/챗봇 scaffold, or a conversational frontend-plus-backend starter, and as the foundation to extend with additional LangGraph nodes."
---

# LLM Chat Scaffold

## Overview

이 스킬은 **동작하는 LLM 채팅 앱 전체**를 번들된 템플릿에서 조립한다. 산출물은 세션 메모리·
SQLite 영속화·Ollama/사내 LLM 전환·연결 테스트·마크다운(표/볼드/mermaid) 렌더링을 갖춘
FastAPI + LangGraph 백엔드와 React + Vite + Tailwind 프론트엔드다.

핵심 설계는 처음부터 다시 발명하기 어렵다(특히 **LangGraph 체크포인터를 thread_id=session_id
로 쓰는 대화 메모리** 구조). 그래서 검증된 소스를 `assets/` 에 통째로 담아두고, 이 문서는
**조립·설정·실행·검증 절차**를 안내한다. 세부 설계 근거는 `references/architecture.md` 참고.

## When to use

- "채팅 앱 / 챗봇 / LLM 웹 UI / 대화형 앱" 을 새로 만들어 달라는 요청
- Ollama 또는 사내 OpenAI 호환 LLM 에 붙는 프론트+백엔드 스타터가 필요할 때
- 세션별 대화 메모리·SQLite·스트리밍 채팅이 필요한 프로젝트의 기반이 필요할 때
- 이후 LangGraph 노드를 추가해 기능을 확장할 토대가 필요할 때

## What gets built

| 영역 | 스택 | 핵심 기능 |
|------|------|-----------|
| Backend | FastAPI, LangGraph, langgraph-checkpoint-sqlite, langchain(ollama/openai), aiosqlite | LLM 백엔드 전환, 세션 CRUD API, SSE 스트리밍 채팅, 세션 메모리, 연결 테스트 |
| Frontend | React 18, Vite, TypeScript, Zustand, Tailwind, react-markdown+remark-gfm, mermaid | 2-pane UI(Sidebar+Chat), 세션 목록/생성/이름변경/삭제, 스트리밍 채팅, 마크다운·표·mermaid 렌더, LLM 연결 테스트 버튼 |

## Build workflow

아래 순서대로 진행한다. 각 단계 끝에서 검증한 뒤 다음으로 넘어간다.

### 1. 대상 위치 확인 & 템플릿 복사

프로젝트 루트를 정한다(사용자가 지정하지 않으면 현재 디렉터리 또는 새 폴더). `assets/` 의
내용을 **그대로** 프로젝트 루트에 복사한다. `assets/` 자체는 옮기지 않고, 그 **안의 항목**을
루트로 옮긴다:

```
<프로젝트 루트>/
├── backend/          ← assets/backend/ 전체
├── frontend/         ← assets/frontend/ 전체
├── dev.py            ← assets/dev.py
└── README.md         ← assets/README.md
```

- 점(.)으로 시작하는 파일도 반드시 복사한다: `backend/.env.example`, `backend/.gitignore`,
  `frontend/.gitignore`.
- 파일 내용은 수정하지 않는다(설계가 서로 맞물려 있다). 사용자가 앱 이름/제목 변경을 원하면
  `frontend/index.html` 의 `<title>`, `backend/app/main.py` 의 `FastAPI(title=...)`,
  `README.md` 정도만 바꾼다.

> 복사 도구: 파일이 많으므로 재귀 복사를 쓴다. Windows PowerShell:
> `Copy-Item -Recurse -Force <skill>/assets/* <프로젝트 루트>/`. Bash: `cp -r assets/. <루트>/`.
> 숨김 파일 포함 여부를 반드시 확인한다.

### 2. 백엔드 설치 & 설정

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate   |  macOS/Linux: source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
```

`.env` 를 사용자의 LLM 환경에 맞춰 편집한다(자세한 값은 `references/architecture.md` 의
"LLM 백엔드 스위칭" 참조):

- **Ollama (기본)**: `LLM_BACKEND=ollama`, `OLLAMA_BASE_URL`, `OLLAMA_MODEL`. Ollama 가 실행
  중이고 모델이 pull 되어 있어야 한다(`ollama pull <model>`).
- **사내 LLM**: `LLM_BACKEND=internal` + `INTERNAL_LLM_BASE_URL`(/v1 포함 권장),
  `INTERNAL_LLM_API_KEY`, `INTERNAL_LLM_MODEL`. 사설 CA 면 `INTERNAL_LLM_CA_BUNDLE`(.pem 경로),
  프록시 우회가 필요하면 `BYPASS_PROXY=true`.

검증: `pytest` 통과 확인 → `uvicorn app.main:app --reload` 로 기동 후 `GET http://localhost:8000/`
가 `{"status":"ok"}`, `GET http://localhost:8000/api/health/llm` 가 `{ok, models, error}` 반환.

### 3. 프론트엔드 설치

```bash
cd frontend
npm install
```

검증: `npm test` 통과 → `npm run dev` 로 `http://localhost:5173` 기동.

### 4. 함께 실행 & 동작 확인

루트에서 `python dev.py` (또는 `python dev.py internal`) 로 백+프론트를 동시에 띄운다. 브라우저가
자동으로 열린다. 다음을 눈으로 확인한다:

1. 사이드바 **LLM 연결 테스트** 버튼 → dot 초록(연결 성공) + 모델 목록 표시.
2. 메시지 전송 → 로딩 dot 후 assistant 응답이 **마크다운(표/볼드/mermaid)** 으로 렌더.
3. 새 세션 생성 → 다른 세션과 대화가 분리됨. 한 세션 안에서 이어지는 질문이 **과거 맥락을 기억**.
4. 세션 이름변경(✎)·삭제(🗑) 동작. 새로고침 후에도 세션·대화가 유지(SQLite 영속).

## Key architecture (요약)

깊이 있는 내용은 `references/architecture.md` 를 로드해 참고한다. 특히 확장·디버깅 전에 읽는다.

- **대화 메모리 = LangGraph 체크포인터**. `main.py` lifespan 에서 `AsyncSqliteSaver` 를 만들어
  `build_graph(model, checkpointer)` 에 주입하고, 매 호출에 `thread_id=session_id` 를 넘긴다.
  같은 thread_id 로 다시 부르면 과거 `messages` 가 자동 복원된다. 직접 messages 테이블을 만들지
  않는다. `sessions` 테이블은 메타데이터(제목/정렬)만 담는다.
- **LLM 전환**은 `config.llm_backend` 한 값(ollama|internal). `llm.py` 가 `ChatOllama` /
  `ChatOpenAI` 를 생성. 사내망 TLS·프록시는 `net.py` 가 처리.
- **스트리밍**은 SSE 3-이벤트(`token`/`done`/`error`). 프론트는 토큰을 버퍼링했다가 `done` 시
  한 번에 렌더한다(마크다운이 조각 단위로 깨지지 않도록).
- **확장**: 그래프 노드는 `graph/builder.py` 에서 add_node + 조건부 엣지로 추가(라우터 노드를
  두고 chat 과 도구 노드를 분기). DB 는 `db/database.py` 스키마에 테이블 추가.

## Notes

- 이 스킬은 **채팅 기반 토대**에 집중한다(파일 업로드·문서 생성·인증 등은 포함하지 않음). 필요하면
  위 확장 지점을 따라 노드/엔드포인트/테이블을 추가한다.
- 포트 기본값: 백엔드 8000, 프론트 5173(프론트가 `/api` 를 8000 으로 프록시). 변경 시
  `frontend/vite.config.ts` 의 proxy 와 `backend` CORS(`CORS_ORIGINS`)를 함께 맞춘다.
- 모든 asset 소스는 상호 의존적이다. 일부만 복사하거나 이름을 바꾸면 import 가 깨진다 —
  전체를 복사한 뒤 실행 검증부터 한다.
